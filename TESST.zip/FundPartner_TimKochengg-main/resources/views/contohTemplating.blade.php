{{-- Ini contoh format --}}
@extends('layout')
@section('content')
{{-- copy setelah div -page wrapper- --}}

@endsection